This repository is governed by the Svelte Code of Conduct.

https://github.com/sveltejs/community/blob/main/CODE_OF_CONDUCT.md
