<script>
	import Nested from './Nested.svelte';
</script>

<p>These styles...</p>
<Nested/>

<style>
	p {
		color: purple;
		font-family: 'Comic Sans MS', cursive;
		font-size: 2em;
	}
</style>