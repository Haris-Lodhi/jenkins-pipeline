<script>
	import Inner from './Inner.svelte';
</script>

<Inner on:message/>