<script>
	import { title, comicSans, box } from './styles.js';
</script>

<div class="{title} {comicSans}">
	<h1>
		<div class={box}>
			<div class={box}>
				<div class={box}>CSS</div>
				in JS
			</div>
			in HTML
		</div>
	</h1>
</div>