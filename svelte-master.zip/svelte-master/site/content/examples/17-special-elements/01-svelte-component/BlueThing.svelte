<strong>Blue thing</strong>

<style>
	strong {
		color: blue;
	}
</style>