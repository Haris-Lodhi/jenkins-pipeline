---
question: Is there a tool to automatically format my .svelte files?
---

You can use prettier with the [prettier-plugin-svelte](https://www.npmjs.com/package/prettier-plugin-svelte) plugin.
