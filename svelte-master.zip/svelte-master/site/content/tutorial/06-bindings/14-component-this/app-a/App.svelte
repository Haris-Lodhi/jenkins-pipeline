<script>
	import InputField from './InputField.svelte';
</script>

<InputField />
