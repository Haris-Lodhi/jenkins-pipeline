<script>
	import { count } from './stores.js';

	function reset() {
		// TODO reset the count
	}
</script>

<button on:click={reset}>
	reset
</button>